import * as React from "react";
import Questions from "../components/Questions";
import { Create } from "../components/Create";
import ParticlesComponent from "../../particle/components/Particle";
import Header from "../../../shared/components/Header";

function Dashboard() {
  return (
    <div style={{ position: "relative" }}>
      <ParticlesComponent id="particles" />
      {/* <Header /> */}
      <Create />
      <Questions />
    </div>
  );
}

export default Dashboard;
