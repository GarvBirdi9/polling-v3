import Box from "@mui/material/Box";
import Fab from "@mui/material/Fab";
import EditIcon from "@mui/icons-material/Edit";
import Form from "./Form";
import { useState } from "react";
import CreateForm from "./CreateForm";

export const Create = () => {
  const [visible, setVisible] = useState(false);
  const shareData = {
    heading: "Create A Question",
    button: "Create",
    option: true,
  };

  return (
    <>
      <Box sx={{ "& > :not(style)": { m: 1 } }}>
        <Fab
          color="#ffffff"
          aria-label="edit"
          style={{
            position: "fixed",
            right: "10px",
            top: "20px",
            boxShadow:
              "  rgba(0, 0, 0, 0.3) 0px 19px 38px, rgba(0, 0, 0, 0.22) 0px 15px 12px",
          }}
          onClick={() => {
            setVisible(true);
          }}
        >
          <EditIcon />
        </Fab>
      </Box>
      <CreateForm
        visible={visible}
        setVisible={setVisible}
        formdata={shareData}
      />
    </>
  );
};
