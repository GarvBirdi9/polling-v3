// import React from "react";
// import "../../stylesheets/Button.css";

// const Button = (props) => {
//   return (
//     <button onClick={props.onclick} className={props.class}>
//       {props.msg}
//     </button>
//   );
// };

// export default Button;

import React from "react";
// import "../../stylesheets/Button.css";

const Button = (props) => {
  const buttonStyle = {
    backgroundColor: "rgba(0, 191, 111, 0.85)",
    color: "white",
    height: "45px",
    fontSize: "1rem",
    borderRadius: "10px",
    border: "1px solid rgba(0, 191, 111)",
    padding: "7px",
    cursor: "pointer",
    margin: "30px 30px",
  };

  const hoverStyle = {
    backgroundColor: "rgba(0, 191, 111, 1)",
  };

  return (
    <button
      onClick={props.onclick}
      className={props.class}
      style={buttonStyle}
      onMouseOver={(e) =>
        (e.currentTarget.style.backgroundColor = hoverStyle.backgroundColor)
      }
      onMouseOut={(e) =>
        (e.currentTarget.style.backgroundColor = buttonStyle.backgroundColor)
      }
    >
      {props.msg}
    </button>
  );
};

export default Button;
